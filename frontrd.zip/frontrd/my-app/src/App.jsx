import { useState } from 'react'
import './App.css'
import Greeting from "./component/Greeting";



function App() {


  return (
    <>
      <Greeting />
    </>
  )
}

export default App
